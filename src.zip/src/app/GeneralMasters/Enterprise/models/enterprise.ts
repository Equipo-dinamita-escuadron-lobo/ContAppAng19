export interface Enterprise {
  nombre: string;
  nit: string;
}
