export interface EnterpriseList{
    id?: number;
    name: String;
    nit: String;
    logo: String;
}
