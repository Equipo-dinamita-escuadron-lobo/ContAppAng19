export interface ThirdType{
     entId:String;
     thirdTypeId: number;
     thirdTypeName:string;
}