export enum eThirdGender{
    masculino = "Masculino",
    femenino = "Femenino",
    Otro = "Otro"
}