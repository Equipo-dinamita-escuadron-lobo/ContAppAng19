export enum ePersonType {
    natural = "Natural",
    juridica = "Juridica",
  }
  