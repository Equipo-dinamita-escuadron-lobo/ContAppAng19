export interface Tooltip {
    entId: string;
    tip: string;
}