export enum eTypeId{
    cc = "CC",
    ce = "CE",
    TI = "NIT",
    pasaporte = "Pasaporte"
}