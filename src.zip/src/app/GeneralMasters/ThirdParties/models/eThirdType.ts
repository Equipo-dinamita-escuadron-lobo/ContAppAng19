export enum eThirdType{
    cliente = "Cliente",
    Proveedor = "Proveedor",
    Empleado = "Empleado",
    otro = "Otro"
}