export interface TypeId{
    entId: String;
    typeId: string;
    typeIdname: string;

}