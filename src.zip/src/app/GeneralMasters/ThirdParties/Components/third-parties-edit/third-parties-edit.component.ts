import { Component } from '@angular/core';

@Component({
  selector: 'app-third-parties-edit',
  imports: [],
  templateUrl: './third-parties-edit.component.html',
  styleUrl: './third-parties-edit.component.css'
})
export class ThirdPartiesEditComponent {

}
