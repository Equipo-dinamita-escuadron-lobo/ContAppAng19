import { Component } from '@angular/core';

@Component({
  selector: 'app-third-parties-create',
  imports: [],
  templateUrl: './third-parties-create.component.html',
  styleUrl: './third-parties-create.component.css'
})
export class ThirdPartiesCreateComponent {

}
