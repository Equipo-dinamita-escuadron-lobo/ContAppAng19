
export interface FinancialStateType{
    id: number;
    name: string;
}