
export interface NatureType {
    id: number;
    name: string;
}