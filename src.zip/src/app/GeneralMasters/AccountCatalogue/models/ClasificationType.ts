export interface  ClasificationType{
    id: number;
    name: string;
}