import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-configuration-main',
  imports: [CommonModule],
  templateUrl: './configuration-main.component.html',
  styleUrls: ['./configuration-main.component.css'],
})
export class ConfigurationMainComponent {
  configItems = [
    {
      name: 'Usuarios',
      route: 'usuarios',
      type: 'usuarios',
      amount: 12,
      icon: 'group',
    },
    {
      name: 'Perfiles',
      route: 'perfiles',
      type: 'roles',
      amount: 4,
      icon: 'admin_panel_settings',
    },
  ];

  constructor(private router: Router, private route: ActivatedRoute) {}

  goTo(route: string): void {
    this.router.navigate([route], { relativeTo: this.route });
  }
}
