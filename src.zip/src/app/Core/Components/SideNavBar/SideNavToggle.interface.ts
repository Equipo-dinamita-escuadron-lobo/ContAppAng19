export interface SideNavToggle{
  screenWidth: number;
  collapsed: boolean;
}
