

export class ProductType {
    id = 0; 
    name = ''; 
    description = '';
    enterpriseId = '';
  }
  