import { Component } from '@angular/core';

@Component({
  selector: 'app-product-creation',
  imports: [],
  standalone: true,
  templateUrl: './product-creation.component.html',
  styleUrl: './product-creation.component.css'
})
export class ProductCreationComponent {

}
