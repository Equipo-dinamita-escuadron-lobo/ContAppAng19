export const environment = {
  production: true,
  keycloak_url: 'http://contables.unicauca.edu.co/',
  keycloak_url_token: 'http://contables.unicauca.edu.co/keycloak/token/',
  API_URL: 'http://contables.unicauca.edu.co/api/',
};
